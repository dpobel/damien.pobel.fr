<?php
/*
 * $Id: config.inc.php 67 2010-09-25 21:23:52Z dapob $
 * $HeadURL: http://projects.pwet.fr/svn/misc/trunk/roundcube_plugins/customcss/config.inc.php $
 *
 */

//$rcmail_config['customcss_files'] = array('custom.css');
