<?php
/*
 * $Id: customcss.php 67 2010-09-25 21:23:52Z dapob $
 * $HeadURL: http://projects.pwet.fr/svn/misc/trunk/roundcube_plugins/customcss/customcss.php $
 *
 */

class customcss extends rcube_plugin
{

    public function init()
    {
        $this->add_hook('render_page', array($this, 'add_customcss'));
    }

    public function add_customcss($args)
    {
        $rcmail = rcmail::get_instance();
        $this->load_config();

        $skin_path = $this->local_skin_path();

        $css_files = $rcmail->config->get('customcss_files', array());

        foreach($css_files as $css_file) {
            $css_file_path = 'plugins/' . __CLASS__ . '/' . $skin_path . '/css/' . $css_file;
            if ( file_exists($css_file_path) ) {
                $this->include_stylesheet($skin_path . '/css/' . $css_file);
            } else {
                write_log('errors', 'CSS file "' . $css_file . '" does not exist');
            }
        }

    }

}

