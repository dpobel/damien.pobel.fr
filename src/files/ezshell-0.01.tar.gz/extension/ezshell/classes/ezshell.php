<?php

class eZShell
{
    private $root;
    private $node;

    public function __construct( $node, $root )
    {
        $this->node = $node;
        $this->root = $root;
    }

    public function __get( $name )
    {
        if ( $name === 'node' )
        {
            return $this->node;
        }
        elseif ( $name == 'path' )
        {
            $path = $this->node->attribute( 'url_alias' );
            if ( $path == '' )
            {
                $path = '/';
            }
            return $path;
        }
    }

    public function execute( $output, $commandArray )
    {
        $methodName = 'do' . $commandArray[0];
        $command = array_shift( $commandArray );
        if ( method_exists( $this, $methodName ) )
        {
            return call_user_func( array( $this, $methodName ),
                                   $output, $commandArray );
        }
        else
        {
            $output->outputLine( $command . ' : command not found', 'error' );
        }
        return false;
    }

    private static function visibilityString( $n )
    {
        $state = 'Visible';
        if ( $n->attribute( 'is_invisible' ) )
        {
            $state = 'Hidden (by superior)';
        }
        elseif ( $n->attribute( 'is_hidden' ) )
        {
            $state = 'Hidden';
        }
        return $state;
    }

    private function dohelp( $o, $paramsArray )
    {
        $o->outputLine( 'Available commands:' );
        $o->outputLine( '  ls [path] : list nodes' );
        $o->outputLine( '  ll [path] : list nodes with more details' );
        $o->outputLine( '  cd [path] : change the current node' );
        $o->outputLine( '  detail [path] : show details' );
        $o->outputLine( '  print [path] : print contents' );
        $o->outputLine( '  exit : quit the shell' );
        return true;
    }

    private function doexit( $o, $paramsArray )
    {
        $o->outputLine( 'See you !' );
        eZExecution::cleanExit();
    }

    private function doprint( $o, $paramsArray )
    {
        $node = $this->node;
        $baseNode = $node;
        if ( !empty( $paramsArray ) )
        {
            $path = trim( $this->path . '/' . $paramsArray[0], '/' );
            $tmp = eZContentObjectTreeNode::fetchByURLPath( $path );
            if ( is_object( $tmp ) )
            {
                $baseNode = $tmp;
            }
            else
            {
                $o->outputLine( 'Can\'t find node with URL=' . $path, 'error' );
                return 1;
            }
        }

        $o->outputLine( 'Node name : ' . $baseNode->attribute( 'name' ), 'headline' );
        $dataMap = $baseNode->attribute( 'data_map' );
        foreach( $dataMap as $attr )
        {
            $o->outputLine( $attr->attribute( 'contentclass_attribute_name' ), 'headline2' );
            if ( $attr->attribute( 'has_content' ) )
            {
                // TODO use templates ?
                if ( $attr->attribute( 'data_type_string' ) == 'ezxmltext' )
                {
                    $o->outputLine( trim( strip_tags( $attr->toString() ) ) );
                }
                elseif ( $attr->attribute( 'data_type_string' ) == 'ezobjectrelationlist' )
                {
                    $content = $attr->attribute( 'content' );
                    foreach( $content['relation_list'] as $info )
                    {
                        $contentObject = eZContentObject::fetch( $info['contentobject_id'] );
                        if ( is_object( $contentObject ) )
                        {
                            $o->outputLine( '   - ' . $contentObject->attribute( 'name' ) );
                        }
                    }
                }
                else
                {
                    $o->outputLine( $attr->toString() );
                }
            }
            else
            {
                $o->outputLine( '(no content)' );
            }
        }
        return 0;
    }

    private function dodetail( $o, $paramsArray )
    {
        $node = $this->node;
        $baseNode = $node;
        if ( !empty( $paramsArray ) )
        {
            $path = trim( $this->path . '/' . $paramsArray[0], '/' );
            $tmp = eZContentObjectTreeNode::fetchByURLPath( $path );
            if ( is_object( $tmp ) )
            {
                $baseNode = $tmp;
            }
            else
            {
                $output->outputLine( 'Can\'t find node with URL=' . $path, 'error' );
                return 1;
            }
        }

        $o->outputLine( $baseNode->attribute( 'name' ), 'headline' );
        $table = new ezcConsoleTable( $o, 240 ); // TODO auto detect width
        $table[0][]->content = 'Owner';
        $table[0][]->content = 'Created';
        $table[0]->format = 'headline';
        $table[1][]->content = $baseNode->attribute( 'object' )
                                        ->attribute( 'owner' )
                                        ->attribute( 'name' );
        $table[1][]->content = strftime( '%x %X', $baseNode->attribute( 'object' )
                                                            ->attribute( 'published' ) );
        $table->outputTable();
        $o->outputLine();
        $o->outputLine( 'Locations', 'headline' );
        $table = new ezcConsoleTable( $o, 240 ); // TODO auto detect width
        $table[0][]->content = 'Path';
        $table[0][]->content = 'Sub items';
        $table[0][]->content = 'Visibility';
        $table[0]->format = 'headline';
        $baseNodes = $baseNode->attribute( 'object' )->attribute( 'assigned_nodes' );
        $i = 1;
        foreach( $baseNodes as $n )
        {
            $pathName = $n->attribute( 'name' );
            if ( $n->attribute( 'url_alias' ) != '' )
            {
                $tmpNode = $n->attribute( 'parent' );
                while ( $tmpNode->attribute( 'url_alias' ) != '' )
                {
                    $pathName = $tmpNode->attribute( 'name' ) . '/' . $pathName;
                    $tmpNode = $tmpNode->attribute( 'parent' );
                }
                $pathName = $tmpNode->attribute( 'name' ) . '/' . $pathName;
            }
            $table[$i][]->content = $pathName;
            $table[$i][]->content = $n->attribute( 'children_count' );
            $table[$i][]->content = self::visibilityString( $n );
            $i++;
        }
        $table->outputTable();
        $o->outputLine();
        return 0;
    }

    private function docd( $output, $paramsArray )
    {
        $node = $this->node;
        if ( empty( $paramsArray ) )
        {
            $this->node = $this->root;
            return true;
        }
        if ( $paramsArray[0] == '..' )
        {
            $tmp = $node->attribute( 'parent' );
        }
        else
        {
            $path = trim( $this->path . '/' . $paramsArray[0], '/' );
            $tmp = eZContentObjectTreeNode::fetchByURLPath( $path );
        }
        if ( is_object( $tmp ) )
        {
            $this->node = $tmp;
            return 0;
        }
        $output->outputLine( 'Can\'t find ' . $path, 'error' );
        return 1;
    }

    private function dols( $output, $paramsArray )
    {
        $node = $this->node;
        $baseNode = $node;
        if ( !empty( $paramsArray ) )
        {
            $path = trim( $this->path . '/' . $paramsArray[0], '/' );
            $tmp = eZContentObjectTreeNode::fetchByURLPath( $path );
            if ( is_object( $tmp ) )
            {
                $baseNode = $tmp;
            }
            else
            {
                $output->outputLine( 'Can\'t find node with URL=' . $path, 'error' );
                return 1;
            }
        }
        if ( $baseNode->attribute( 'children_count' ) != 0 )
        {
            $children = $baseNode->attribute( 'children' );
            $table = new ezcConsoleTable( $output, 240 ); // TODO auto detect width
            $table[0][]->content = 'Node id';
            $table[0][]->content = 'Name';
            $table[0][]->content = 'URL';
            $table[0]->format = 'headline';
            $i = 1;
            foreach( $children as $element )
            {
                $table[$i][]->content = $element->attribute( 'node_id' );
                $table[$i][]->content = $element->attribute( 'name' );
                $table[$i][]->content = array_pop( explode( '/', $element->attribute( 'url_alias' ) ) );
                $i++;
            }
            $table->outputTable();
            $output->outputLine();
        }
        else
        {
            $output->outputLine( 'This element doesn\'t have sub-items' );
        }
        return 0;
    }


    private function doll( $output, $paramsArray )
    {
        $node = $this->node;
        $baseNode = $node;
        if ( !empty( $paramsArray ) )
        {
            $path = trim( $this->path . '/' . $paramsArray[0], '/' );
            $tmp = eZContentObjectTreeNode::fetchByURLPath( $path );
            if ( is_object( $tmp ) )
            {
                $baseNode = $tmp;
            }
            else
            {
                $output->outputLine( 'Can\'t find node with URL=' . $path, 'error' );
                return 1;
            }
        }
        if ( $baseNode->attribute( 'children_count' ) != 0 )
        {
            $children = $baseNode->attribute( 'children' );
            $table = new ezcConsoleTable( $output, 240 ); // TODO auto detect width
            $table[0][]->content = 'Node id';
            $table[0][]->content = 'Name';
            $table[0][]->content = 'URL';
            $table[0][]->content = 'Owner';
            $table[0][]->content = 'Published';
            $table[0][]->content = 'Modified';
            $table[0][]->content = 'Visibilty';
            $table[0]->format = 'headline';
            $i = 1;
            foreach( $children as $element )
            {
                $table[$i][]->content = $element->attribute( 'node_id' );
                $table[$i][]->content = $element->attribute( 'name' );
                $table[$i][]->content = array_pop( explode( '/', $element->attribute( 'url_alias' ) ) );
                $table[$i][]->content = $element->attribute( 'object' )->attribute( 'owner' )->attribute( 'name' );
                $table[$i][]->content = strftime( '%x %X', $element->attribute( 'object' )
                                                                        ->attribute( 'published' ) );
                $table[$i][]->content = strftime( '%x %X', $element->attribute( 'object' )
                                                                        ->attribute( 'modified' ) );
                $table[$i][]->content = self::visibilityString( $element );
                $i++;
            }
            $table->outputTable();
            $output->outputLine();
        }
        else
        {
            $output->outputLine( 'This element doesn\'t have sub-items' );
        }
        return 0;
    }


}


?>
